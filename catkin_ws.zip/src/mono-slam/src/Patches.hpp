#include "Patch.hpp"

#ifndef __PATCHES_CLASS__
#define __PATCHES_CLASS__

#include <opencv2/opencv.hpp>
#include <eigen3/Eigen/Dense>


using namespace Eigen;

class Patch: public std::vector<Patch> {
protected:
	
	
	
	
public:

};

#endif
