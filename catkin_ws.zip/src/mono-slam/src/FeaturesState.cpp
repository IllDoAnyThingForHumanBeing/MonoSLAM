

#include "FeaturesState.h"

FeaturesState::FeaturesState() {
	// TODO Auto-generated constructor stub

}

FeaturesState::~FeaturesState() {
	// TODO Auto-generated destructor stub
}
